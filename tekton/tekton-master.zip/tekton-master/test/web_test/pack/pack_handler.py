__author__ = 'renzo'

def complete_path():
    pass

def with_params(param1,param2):
    pass

def with_defaults(param1=1,param2=2):
    pass

def with_vargs(param1,*args):
    pass

def with_kwargs(param1,*args,**kwargs):
    pass
