from os import listdir

INDEX_RETURN="index return"

def security_test():
    print listdir("/")



def index():
    return INDEX_RETURN

def fcn_req_resp_handler(request,response,handler,param):
    pass

def fcn_req_resp_handler_default_vargs_kwargs(request,response,handler,param,*args,**kwargs):
    pass

def fcn_resp_handler(response,handler,param):
    pass

def fcn_req_handler(request,handler,param):
    pass

def fcn_req_resp(request,response,param):
    pass

def fcn_request(request,param):
    pass

def fcn_response(response,param):
    pass

def fcn_handler(handler,param):
    pass

